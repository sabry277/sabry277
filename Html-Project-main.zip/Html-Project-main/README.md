# covid-19
basic Web Page built using html for role of computer engineering in this panademic
